#include <iostream>
using namespace std;

void print_sorted_outputs(int* a, int*b, 
		int sizeA, int sizeB) {
}

int main() {

}

