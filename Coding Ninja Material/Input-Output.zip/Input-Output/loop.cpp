#include<iostream>
using namespace std;
int main() {
    int n;
    for (n=7;n!=0;n--) {
        cout << n--;
    }
    return 0;
}
