#include<iostream>
using namespace std;
int main() {
    int a,b;
    a = 1,2,3;
    b = (1,2,3);
    cout << a <<"  "<< b << endl;
    return 0;
}
