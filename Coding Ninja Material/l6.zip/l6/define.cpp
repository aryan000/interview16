#include <iostream>
#define PI abc
using namespace std;

inline int max(int a, int b) {
	int output = (a > b)? a : b;
	return output;
}

int main() {
	int a, b;
	int max1;
	max1 = max(a,b);
	double abc = 3.14;
	double a = PI * 3 * 3;
}

